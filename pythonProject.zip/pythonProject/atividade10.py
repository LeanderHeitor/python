tipoCombustivel = input("qual o tipo de combustivel?")

valorE = 4.90
valorG = 5.80
if tipoCombustivel == "E" or tipoCombustivel == "e":
    litros = float(input("quantos litros"))
    total = valorE * litros
    print(f"vc gastou {total}")
elif tipoCombustivel == "G" or tipoCombustivel == "g":
    litros = float(input("quantos litros"))
    total = valorG * litros
    print(f"vc gastou {total}")
else:
    print("invalido")