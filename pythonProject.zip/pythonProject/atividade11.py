numero = input("digite um numero")
if numero%2==0:
    print("o número é par")
else:
    print("o número é impar")