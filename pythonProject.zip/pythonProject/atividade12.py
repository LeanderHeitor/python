horaUm = int(input("digite a hora um"))
minutoUm = int(input("digite os primeiros minutos"))
horaDois = int(input("digite a hora Dois"))
minutoDois = int(input("digite os segundos minutos"))
horafinal = horaUm + horaDois
minutosTotais = minutoUm + minutoDois
if minutosTotais > 60:
    minutosTotais = minutosTotais % 60
    horafinal = horafinal + minutosTotais // 60
if horafinal > 24:
    horafinal -= 24
if horafinal > 12:
    horafinal -= 12
    periodo = 'PM'
else:
    periodo = 'AM'
print(f"As horas são {horafinal}:{minutosTotais} {periodo}")