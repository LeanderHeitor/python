
num = int(input("escolha um número: "))
for x in range(1,11,1):
    print(f"{num} x {x} = {num*x}")