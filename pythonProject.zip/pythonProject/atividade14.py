positivo = 0
negativo = 0
for x in range(0,10,1):
    num = int(input("escreva um número"))
    if num < 0:
        negativo = negativo+1
        print(f"negativos: {negativo} ")
    else:
       positivo = positivo + 1
       print(f"positivos: {positivo} ")
print(f"a quantidade de números negativos é de: {negativo} ")
print(f"a quantidade de números positivos é de: {positivo} ")