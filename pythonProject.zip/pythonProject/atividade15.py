dentro = 0
fora = 0
for x in range(0,10,1):
    num = int(input("escreva um número"))
    if num <= 20 and num >= 10:
        dentro = dentro+1
        print(f"dentro: {dentro} ")
    else:
       fora = fora + 1
       print(f"fora: {fora} ")
print(f"a quantidade de números dentro do intervalo de [10,20] é de: {dentro} ")
print(f"a quantidade de números fora do intervalo de [10,20] é de: {fora} ")