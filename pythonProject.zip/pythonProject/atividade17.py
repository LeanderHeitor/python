somaNota = 0
contador = 0
for x in range (1,10,1):
    valores = float(input(f"digite números para o calculo da media"))
    if valores>=0 and valores <=10:
        somaNota = somaNota + valores
        contador = contador + 1
    else:
        print("valor invalido")
media = (somaNota/contador)
print(f"sua média é {media}")