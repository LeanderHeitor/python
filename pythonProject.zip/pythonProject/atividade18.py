n=0
while n < 10:
    print(f"n tem valor de {n}")
    n = n+1