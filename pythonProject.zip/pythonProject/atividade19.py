n=0
somaNota = 0
while n<10:
    nota = float(input("digite as notas"))
    if nota >=0 and nota <=10:
        somaNota = somaNota + nota
        n=n+1
    else:
        print("invalido")
media = somaNota/n
print(f"sua media é de: {media}")