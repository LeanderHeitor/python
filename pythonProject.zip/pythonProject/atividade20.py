x = 0
somaNota = 0
qtd = 0
qtdAlunos = int(input("quantos alunos existem em sala?"))
while x<qtdAlunos:
    nota = float(input("digite as notas"))
    if nota >= 0 and nota <= 10:
        somaNota = somaNota + nota
        qtd = qtd+1
    else:
        print("invalido")
x=x+1
media = somaNota / x
print(f"sua media é de: {media}")