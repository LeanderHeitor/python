x = 0
while x == 0:
    numUm = int(input("digite o num 1"))
    numDois = int(input("digite o num 2"))
    while numDois==0:
        print("só será aceito valores diferentes de 0")
        numDois = int(input("digite o num 2"))
    print(f"o valor da divisão será de {numUm/numDois}")
    x = float(input("gostária de fazer outra operação? 0 para sim, 1 para não"))