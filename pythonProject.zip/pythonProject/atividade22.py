#receba a senha do usuario se errar 3x dizer q a senha foi bloqueada e terminar
senha = 12345
senhaRecebida = 0
tentativas = 0
while tentativas < 3:
    senhaRecebida = int(input("qual a senha?"))
    if senhaRecebida != senha:
        print(f"senha incorreta")
        tentativas = tentativas + 1
        print(f"você errou a senha {tentativas} vez/vezes ")
        print(f"na terceira tentativa errada, a sua conta será bloqueada")
    else:
        break
if senhaRecebida == senha:
    print("bem-vindo a sua conta")
    print("*_*")
else:
    print(f"você errou sua senha {tentativas} vezes")
    print(f"sua conta foi bloqueada")