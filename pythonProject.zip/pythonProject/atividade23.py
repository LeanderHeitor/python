nota = float(input("digite as notas"))
while nota < 0 or nota > 10:
    print("valor invalido, digite uma nota que seja valida")
    nota = float(input("digite a nota"))
notaDois = float(input("digite a nota dois"))
while notaDois < 0 or notaDois > 10:
    print("valor invalido, digite uma nota que seja valida")
    notaDois = float(input("digite a nota"))
media = (nota + notaDois) / 2
print(f"sua media é de: {media}")