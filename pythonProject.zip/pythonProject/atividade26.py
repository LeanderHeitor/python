contador = 0
nome = input("diga seu belo nome")

for x in nome:
    contador = contador + 1

print(f"o nome escolhido tem {contador} letras ")
