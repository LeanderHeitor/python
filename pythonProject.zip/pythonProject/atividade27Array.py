listaNomes = [" "," "," "," "," "]
for x in range(0,5,1):
    y = input("digite o nome:")
    listaNomes[x]=y
    #ou
    #listaNomes[x] = input("digite o nome:")
for z in range(0,5,1):
    print(listaNomes[z],z)