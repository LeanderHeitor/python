somaNotas = 0
contador = 0
contAcimaDaMedia = 0
listaNotas = [0,0,0,0,0]
for x in range(0,5,1):
    y = float(input("digite a nota:"))
    listaNotas[x]=y
    #ou
    #listaNomes[x] = input("digite o nome:")
for z in range(0,5,1):
    somaNotas = somaNotas + listaNotas[z]
    contador = contador + 1
    print(somaNotas)
    media = somaNotas/contador
print(f"a media tem valor de {media}")
for a in range(5):
    if listaNotas[a]>=media:
        contAcimaDaMedia = contAcimaDaMedia + 1
print(f"a media da turma é {media} e {contAcimaDaMedia} foram aprovados")