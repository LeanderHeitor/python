somaNotas = 0
A = [0,0,0,0,0,0,0,0,0,0]
M = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
for x in range(0,10,1):
    y = float(input("digite um num:"))
    A[x]=y
mult = float(input("e o mult?"))
for z in range(0,10,1):
    somaNotas = mult * A[z]
    M[z] = somaNotas
print(A)
print(M)