valores = [" "," "," "," "," "]
for i in range(5):
    valores[i] = int(input("digite valores:"))
print(valores)
for x in range(4,-1,-1):
    print(valores[x])