opcao = 0
une = 0

while opcao != 3:
    print("")
    print("")
    print("")