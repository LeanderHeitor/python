#FUNÇÕES
def mostrarNome(nome):
    print(f"Nome: {nome}")

mostrarNome("eitô")
mostrarNome("jonas")
mostrarNome("marcio")