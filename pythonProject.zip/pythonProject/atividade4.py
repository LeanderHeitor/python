nome = input("Digite seu nome: ")
notaUm = float(input("Digite a primeira nota: "))
notaDois = float(input("Digite a segunda nota: "))
media = (notaUm + notaDois) / 2
print("seu nome é", nome, "e a sua média é de ", media)
