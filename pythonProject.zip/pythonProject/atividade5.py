numeroUm = float(input("digite o primeiro numero: "))
numeroDois = float(input("digite o segundo numero: "))

Sum = numeroUm + numeroDois
Sub = numeroUm - numeroDois
Mult = numeroUm * numeroDois
Div = numeroUm / numeroDois

print(f"o resultado da soma é: {Sum}")
print(f"o resultado da subtração é: {Sub}")
print(f"o resultado da multiplicaçãp é: {Mult}")
print(f"o resultado da divisão é: {Div}")


