A=5
B=10
print(f"valor de A: {A}")
print(f"valor de B: {B}")
troca = A #troca = 5, A = 5, B = 10
A = B
B = troca
print(f"valor de A: {A}")
print(f"valor de B: {B}")
