numeroUm = float(input("Digite o primeiro numero: "))
numeroDois = float(input("Digite o segundo numero: "))

if numeroUm == numeroDois:

    print(f"são iguais")
elif numeroUm > numeroDois:

    print(f"logo a ordem é : {numeroDois}, {numeroUm}")
else:
    print(f"logo a ordem é {numeroUm},{numeroDois} ")
