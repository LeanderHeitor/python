notaUm = float(input("insira a primeira nota:"))
notaDois = float(input("insira a segunda nota:"))
notaTres = float(input("insira a terceira nota:"))

media = (notaUm + notaDois + notaTres) / 3

if 7 > media > 4:
    print(f" Sua média foi de: {media}, logo você está de recuperação")
else:
    if media>=7:
        print(f" Sua média foi de: {media}, logo você está aprovado")
    else:
        print(f" Sua média foi de: {media}, logo você está reprovado")
