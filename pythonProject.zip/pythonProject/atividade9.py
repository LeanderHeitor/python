timeUm = input("qual o primeiro time: ")
quantidadeGolsTimeUm = int(input(f"quantos gols {timeUm} fez?: "))
timeDois = input("qual o segundo time: ")
quantidadeGolsTimeDois = int(input(f"quantos gols {timeDois} fez?: "))

if quantidadeGolsTimeUm == quantidadeGolsTimeDois:
    print(f"o {timeUm} empatou com {timeDois}, o jogo terminou {quantidadeGolsTimeDois} - {quantidadeGolsTimeUm}")
elif quantidadeGolsTimeUm > quantidadeGolsTimeDois:
    print(f"o {timeUm} ganhou do/a {timeDois}, o jogo terminou {quantidadeGolsTimeUm} - {quantidadeGolsTimeDois}")
else:
    print(f"o {timeDois} ganhou do/a {timeUm}, o jogo terminou {quantidadeGolsTimeDois} - {quantidadeGolsTimeUm}")
    