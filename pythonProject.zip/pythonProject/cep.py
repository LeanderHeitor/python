import requests
import mysql.connector

banco  = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="desafioB"
)
meucursor = banco.cursor()
print("verificar endereço")
nome1 = input("escreva o nome a ser adicionado")
cep = input("digite o cep: ")
if len(cep)!=8:
    print("cep invalido")
    exit()
consulta = requests.get(f"https://viacep.com.br/ws/{cep}/json/")
endereco = consulta.json()
cep1 = endereco['cep']
logradouro = endereco['logradouro']
complemento = endereco['complemento']
bairro = endereco['bairro']
localidade = endereco['localidade']
uf = endereco['uf']
sql = "INSERT INTO enderecos (nome,logradouro,complemento,cep,bairro,localidade,uf) VALUES (%s, %s, %s, %s, %s, %s, %s)"
data = (nome1, logradouro,complemento,cep1,bairro,localidade,uf)
meucursor.execute(sql, data)
banco.commit()
print(cep1,logradouro)
meucursor.close()
banco.close()