from funcoes import *
resultado = tratartexto("comentando comentarios especificos")
print(resultado)
