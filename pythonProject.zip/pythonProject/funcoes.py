# criando função
def piramide(n):
    for x in range(1, n + 1):
        for y in range(1, x + 1):
            print(y, end=" ", )
        print()
def vogais(texto):
    cont = 0
    for x in range (len(texto)):
        print(texto[x])
        if texto[x] != " ":
            if texto[x] == "a" or texto[x] == 'A' or texto[x] == "e" or texto[x] == 'E' or texto[x] == "i" or texto[x] == 'I' or texto[x] == "o" or texto[x] == 'O' or texto[x] == "u" or texto[x] == 'U':
                cont = cont + 1
    print(cont)
def palavra(texto):
    cont = 0
    y = "aeiouAEIOU"
    for x in texto:
        if x in y:
            cont = cont + 1
    print(cont)
def valorTotal(prod, qtd, valor):
    valorFinal = qtd * valor
    return f"seu produto é {prod}, existem {qtd} no estoque, custando {valor} cada, o valor total é de {valorFinal}"
    
    for x in range(qtd):
        somaValor = valor + somaValor
    print(somaValor)
def positivoOuNegativo(num):
    if num>0:
        return f"{num} é P"
    elif num<0:
        return f"{num} é N"
    else:
        return f"{num} é z"
produto = []
preco = []
def estoque2(nome,valor):
    produto.append(nome)
    preco.append(valor)
def somar(num1,num2):
    return num1 + num2
def somar2(*numeros):
    soma = 0
    for x in range(len(numeros)):
        soma = soma + numeros[x]
    return soma
texto = ""
def tratartexto (palavra):
    cont = 0
    for x in palavra:
        if x not in  " .,!":
            cont = cont + 1

    for z in range(len(palavra)-1,-1,-1):
        print(palavra[z], end=" ")

    return f"tem {cont} letras "