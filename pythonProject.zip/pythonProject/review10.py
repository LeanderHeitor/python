eleitoresTotal = int(input("quantos eleitores tivemos no total?"))
eleitoresNulo = int(input("quantos eleitores votaram nulo"))
eleitoresBranco = int(input("quantos eleitores votaram branco"))

votosValidos = eleitoresTotal - (eleitoresNulo+eleitoresBranco)
porcentagemValido = (votosValidos / eleitoresTotal) * 100
porcentagemBranco = (eleitoresBranco / eleitoresTotal) * 100
porcentagemNulo = (eleitoresNulo / eleitoresTotal) * 100
print(f" a porcentagem de votos validos foi de: {porcentagemValido}%")
print(f" a porcentagem de votos nulos foi de: {porcentagemNulo}%")
print(f" a porcentagem de votos brancos foi de: {porcentagemBranco}%")
