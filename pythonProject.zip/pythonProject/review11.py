horaInicio = int(input("digite a hora um"))
horaFim = int(input("digite a hora Dois"))
horafinal = horaFim - horaInicio
if horafinal > 24:
    horafinal -= 24
elif horafinal<0:
    horafinal +=24

print(f"As horas são {horafinal}")
