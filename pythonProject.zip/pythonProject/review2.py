numero = int(input("digite um numero: "))

if numero > 0:
    print("o número é positivo")
elif numero < 0:
    print("o número é negativo")
else:
    print("é zero")