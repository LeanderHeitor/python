idade = int(input("qual a sua idade?: "))
anoAtual=2024
anoNascimento = anoAtual-idade
aniversario = input("você ja fez aniversário? s/S = Sim, n/N = Não: ")
if aniversario == "s" or aniversario == "S":
    print(anoNascimento)
elif aniversario == "n" or aniversario == "N":
    print((anoNascimento)-1)