numero = int(input("diga o número: "))
numero2 = int(input("diga o número 2: "))
numero3 = int(input("diga o número 3: "))

if numero>numero2 and numero > numero3:
    print(f"o numero {numero} é maior que {numero2} e {numero3}")
elif numero2>numero3 and numero2 > numero:
    print(f"o numero {numero2} é maior que {numero} e {numero3}")
else:
    print(f"o numero {numero3} é maior que {numero2} e {numero}")-[]