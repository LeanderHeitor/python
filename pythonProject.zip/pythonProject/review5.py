numero = int(input("digite um número"))

if numero == 0:
    print("digite um número válido")
elif numero % 2 == 0:
    print("é par")
else:
    print("é impar")
