escolha = 0
while escolha !=3:
    print("bem-vindo ao calculo de bases *-*")
    escolha = int(input("1 - Calculo da base de um triângulo ""\n"
                        "2 - Calculo da base de um quadrado""\n"
                        "3 - Finalizar o programa""\n"))
    if escolha == 1:
        base = float(input("qual o valor da base do triângulo: "))
        altura = float(input("qual a altura do triângulo: "))
        area = (base * altura) / 2
        print(f"a área do triângulo é {area}, :D")
    elif escolha == 2:
        lado = float(input("qual o valor do lado do quadrado?: "))
        area = lado ** 2
        print(f"a área do quadrado é {area}: )")
    elif escolha == 3:
        print("Obrigado por usar ! B)")
        break
    else:
        print("insira um valor valido :(")