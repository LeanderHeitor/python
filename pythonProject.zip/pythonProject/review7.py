"""
n1 = float(input("diga ai a primeira nota: "))
n2 = float(input("diga ai a segunda: "))
n3 = float(input("diga ai a terceiro: "))
n4 = float(input("diga ai a quarta: "))
media = (n1+n2+n3+n4)/4
print(f"a sua media é: {media}")
"""
soma = 0
for x in range (4):
    n = float(input("digite um numero: "))
    soma = soma + n
media = soma/4
print(soma,media)