num = int(input("diga um numero"))
antecessor = num - 1
sucessor = num + 1
print(f" o numero antecessor do {num}, é o número {antecessor}")
print(f" o numero antecessor do {num}, é o número {sucessor}")