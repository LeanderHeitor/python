anos = int(input("quantos anos vc tem?"))
meses = int(input("quantos meses vc tem?"))
dias = int(input("quantos dias vc tem?"))
anosPraMeses = anos * 12
mesesTotais = anosPraMeses + meses
print(mesesTotais)
mesesPraDias = mesesTotais * 30
print(mesesPraDias)
diasTotais = mesesPraDias + dias
print(f"você vivel {diasTotais} dias")