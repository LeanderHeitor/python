n1 = float(input("diga ai a primeira nota: "))
n2 = float(input("diga ai a segunda: "))
media = (n1+n2)/2

print(f"a sua media é: {media}")