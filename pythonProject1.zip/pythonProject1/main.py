import mysql.connector

banco  = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="desafioB"
)
meucursor = banco.cursor()
escolha = 0
while escolha != 3:
    print("1 - Consultar")
    print("2 - Inserir")
    print("3 - Sair")
    escolha = int(input("escolha uma das opções: "))
    if escolha == 1:
        pesquisa = 'select * from alunos;'
        meucursor.execute(pesquisa)
        # fetchall recebe reecebe tudo da pesquisa e retorna atraves de uma tubla
        resultado = meucursor.fetchall()
        for x in resultado:
            print(x)

    elif escolha == 2:
        nome1 = input("escreva o nome a ser adicionado")
        telefone1 = input("escreva o seu telefone(11 caracteres)")
        sql = "INSERT INTO alunos (nome,telefone) VALUES (%s, %s)"
        data = (nome1, telefone1)
        meucursor.execute(sql, data)
        banco.commit()
    elif escolha == 3:
        print("até a proxima")
        meucursor.close()
        banco.close()
#userid = cursor.lastrowid
#print(userid)
